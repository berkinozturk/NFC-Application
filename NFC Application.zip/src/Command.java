import java.util.ArrayList;
import java.util.HashMap;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

//Command
interface Command {
    public void Execute();
    public void UnExecute();
}

//Concrete Command
class AssignTag implements Command {
    public AssignTag(StudentAffairsDirectorate studentAffairsDirectorate, Classroom classroom,HashMap<Course,ArrayList<Students>> courseAndStudents) {
        _studentAffairsDirectorate = studentAffairsDirectorate;
        _classroom = classroom;
        _courseAndStudents = courseAndStudents;
    }
    public void Execute() {
        _studentAffairsDirectorate.assignTag(_classroom,_courseAndStudents);
    }

    @Override
    public void UnExecute() {

    }

    private StudentAffairsDirectorate _studentAffairsDirectorate;
    private Classroom _classroom;
    private HashMap<Course, ArrayList<Students>> _courseAndStudents;
}


//Receiver
class StudentAffairsDirectorate {
    public static StudentAffairsDirectorate getInstance() {
        if (instance == null) {
            lock.lock();
            try {
                if (instance == null)
                    instance = new StudentAffairsDirectorate();
            } finally {
                lock.unlock();
            }
        }
        return instance;
    }
    public void assignTag(Classroom classroom,HashMap<Course,ArrayList<Students>> courseAndStudents){
        String tag = "tag" + currentTagNo;
        classroom.getNFCTag().setTagNo(tag);
        classroom.getNFCTag().getCourseAndStudents().putAll(courseAndStudents);
    }
    private int currentTagNo = 1;

    private static StudentAffairsDirectorate instance = null;

    private static final Lock lock = new ReentrantLock();
}

class NFCTag {
    private String tagNo = null;
    private HashMap courseAndStudents = new HashMap<>();

    public NFCTag(String tagNo, HashMap courseAndStudents) {
        this.tagNo = tagNo;
        this.courseAndStudents = courseAndStudents;
    }

    public void setTagNo(String tagNo) {
        this.tagNo = tagNo;
    }

    public HashMap<Course,ArrayList<Students>> getCourseAndStudents() {
        return courseAndStudents;
    }

    public void setCourseAndStudents(HashMap courseAndStudents) {
        this.courseAndStudents = courseAndStudents;
    }

    public String getTagNo() {
        return tagNo;
    }



}

//This is Singleton class
//Invoker
class User {

    public User() {current = 0; }

    public void Redo(int levels) {
        System.out.println("\n---- Redo " + levels + " levels ");
        // Perform redo operations
        for (int i = 0; i < levels; i++) {
            if (current < _commands.size()) {
                Command command = _commands.get(current++);
                command.Execute();
            }
        }
    }

    void Undo(int levels) {
        System.out.println("\n---- Undo " + levels + " levels ");
        // Perform undo operations
        for (int i = 0; i < levels; i++) {
            if (current > 0) {
                Command command = _commands.get(--current);
                command.UnExecute();
            }
        }
    }

    void Compute(Command command) {
        command.Execute();
        // Add command to undo list
        _commands.add(command);
        current++;
    }

    public static User getInstance() {
        if (instance == null) {
            lock.lock();
            try {
                if (instance == null)
                    instance = new User();
            } finally {
                lock.unlock();
            }
        }
        return instance;
    }
    public void doCommand(Command command){
        command.Execute();
        // Add command to undo list
    }

    // Initializers.
    private static User instance = null;
    private static final Lock lock = new ReentrantLock();
    private int current;
    private ArrayList<Command> _commands = new ArrayList<Command>();
}
