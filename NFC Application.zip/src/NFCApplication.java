import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

//Berkin Öztürk
//Ali Doğan Güllü
//Zeynep Hacılar
//Tolunay Akbulut

//Facade
class CourseSetter {

    public CourseSetter(Course course, ArrayList<Students> courseStudents) {
        this.courseStudents = courseStudents;
        this.course = course;
    }
    private Course course;
    private ArrayList<Students> courseStudents;
    private HashMap<Course,ArrayList<Students>> courseAndStudents = new HashMap<Course,ArrayList<Students>>();
    private TagAssign tagAssign = new TagAssign();

    private ClassroomAttach classroomAttach = new ClassroomAttach();

    private AddStudent addStudent = new AddStudent();

    public void set(){
        addStudent.add(course.getCourseClassroom(),courseStudents,course);
        tagAssign.assign(course.getCourseClassroom(),courseAndStudents);
        classroomAttach.attach(course.getCourseClassroom(),courseAndStudents);
    }
}

//Subsystem Class
class AddStudent {
    public void add(Classroom courseClassroom, ArrayList<Students> courseStudents, Course course){
        courseClassroom.getNFCTag().getCourseAndStudents().put(course,courseStudents);
    }
}

//Subsystem Class
class TagAssign {
    public void assign(Classroom courseClassroom,HashMap<Course,ArrayList<Students>> courseAndStudents){

        User user = User.getInstance();
        StudentAffairsDirectorate studentAffairsDirectorate = StudentAffairsDirectorate.getInstance();

        Command command = new AssignTag(studentAffairsDirectorate,courseClassroom,courseAndStudents);
        user.doCommand(command);

    }
}

//Subsystem Class
class ClassroomAttach {
    public void attach(Classroom classroom, HashMap<Course, ArrayList<Students>> hashMap){

        ArrayList<Students> classroomStudents = new ArrayList<>();

        for(Map.Entry<Course, ArrayList<Students>> entry : hashMap.entrySet()) {
            Course key = entry.getKey();
            ArrayList<Students> value = entry.getValue();

            value.forEach((n) -> classroomStudents.add(n));
        }
        classroomStudents.forEach((n) -> classroom.set_student(n));
        classroomStudents.forEach((n) -> n.Attach(classroom));

    }
}
//This class is not about the pattern.
class Course {
    private String courseName;
    private String courseTime;
    private Classroom courseClassroom;

    public Course(String courseName, String courseTime, Classroom courseClassroom) {
        this.courseName = courseName;
        this.courseTime = courseTime;
        this.courseClassroom = courseClassroom;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public String getCourseTime() {
        return courseTime;
    }

    public void setCourseTime(String courseTime) {
        this.courseTime = courseTime;
    }

    public Classroom getCourseClassroom() {
        return courseClassroom;
    }

    public void setCourseClassroom(Classroom courseClassroom) {
        this.courseClassroom = courseClassroom;
    }
}

//Main Class


public class NFCApplication {
    public static void main(String[] args) {

        //-----------------------------Composite task1-----------------------------------

        //create university
        Component university = new CompositeElement("Izmir University of Economics");
        Component E_block = new CompositeElement("Engineering Building");
        CompositeElement CE_floor = new CompositeElement("Computer Engineering Floor");
        CompositeElement SE_floor = new CompositeElement("Software Engineering Floor");
        Classroom CE_1 = new Classroom("Computer Engineering Classroom 1");
        Classroom CE_2 = new Classroom("Computer Engineering Classroom 2");
        Classroom CE_3 = new Classroom("Computer Engineering Classroom 3");
        Classroom SE_1 = new Classroom("Software Engineering Classroom 1");
        Classroom SE_2 = new Classroom("Software Engineering Classroom 2");
        CE_floor.Add(CE_1);
        CE_floor.Add(CE_2);
        CE_floor.Add(CE_3);
        SE_floor.Add(SE_1);
        SE_floor.Add(SE_2);
        E_block.Add(CE_floor);
        E_block.Add(SE_floor);
        university.Add(E_block);
        //university.Display(1);

        //-------------------------------------------------------------------------------

        //Create Students
        Student ali = new Student("ali dogan gullu");
        Student berkin = new Student("berkin ozturk");
        Student zeynep = new Student("zeynep hacılar");
        Student tolunay = new Student("tolunay akbulut");
        Student ufuk = new Student("ufuk");


        //Create course and send information to StudentAffairs with using Facade.
        Course CE101 = new Course("CE101","Pzt 10.00",CE_1);
        ArrayList<Students> CE101_courseStudents = new ArrayList<>();
        CE101_courseStudents.add(ali);
        CourseSetter setCE101 = new CourseSetter(CE101,CE101_courseStudents);
        setCE101.set();

        //Others with facade
        Course CE102 = new Course("CE102","Pzt 12.00",CE_1);
        ArrayList<Students> CE102_courseStudents = new ArrayList<>();
        CE102_courseStudents.add(ali);
        CourseSetter setCE102 = new CourseSetter(CE102,CE102_courseStudents);
        setCE102.set();

        Course CE201 = new Course("CE201","Pzt 10.00",CE_2);
        ArrayList<Students> CE201_courseStudents = new ArrayList<>();
        CE201_courseStudents.add(berkin);
        CourseSetter setCE201 = new CourseSetter(CE201,CE201_courseStudents);
        setCE201.set();

        Course CE202 = new Course("CE202","Pzt 12.00",CE_2);
        ArrayList<Students> CE202_courseStudents = new ArrayList<>();
        CE202_courseStudents.add(berkin);
        CourseSetter setCE202 = new CourseSetter(CE202,CE202_courseStudents);
        setCE202.set();

        Course SE101 = new Course("SE 101","Pzt 10.00",SE_1);
        ArrayList<Students> SE101_courseStudents = new ArrayList<>();
        SE101_courseStudents.add(zeynep);
        CourseSetter setSE101 = new CourseSetter(SE101,SE101_courseStudents);
        setSE101.set();

        Course SE102 = new Course("SE 102","Pzt 12.00",SE_1);
        ArrayList<Students> SE102_courseStudents = new ArrayList<>();
        SE102_courseStudents.add(zeynep);
        CourseSetter setSE102 = new CourseSetter(SE102,SE102_courseStudents);
        setSE102.set();

        Course CE301 = new Course("CE 301","Pzt 10.00",CE_3);
        ArrayList<Students> CE301_courseStudents = new ArrayList<>();
        CE301_courseStudents.add(ufuk);
        CourseSetter setCE301 = new CourseSetter(CE301,CE301_courseStudents);
        setCE301.set();

        //Create course and send information to StudentAffairs without using Facade.
        HashMap<Course,ArrayList<Students>> SE2_CourseAndStudents = new HashMap<>();
        Course SE201 = new Course("SE 201","Pzt 10.00",SE_2);
        ArrayList<Students> SE201_courseStudents = new ArrayList<>();
        SE201_courseStudents.add(tolunay);
        AddStudent addStudent = new AddStudent();
        addStudent.add(SE_2,SE201_courseStudents,SE201);
        TagAssign tagAssign = new TagAssign();
        tagAssign.assign(SE_2,SE2_CourseAndStudents);
        ClassroomAttach classroomAttach = new ClassroomAttach();
        classroomAttach.attach(SE_2,SE2_CourseAndStudents);


        //Other way without using facade.
        ArrayList<Students> SE202_courseStudents = new ArrayList<>();
        SE202_courseStudents.add(tolunay);

        Course SE202 = new Course("SE202","Pzt 12.00",SE_2);
        SE2_CourseAndStudents.put(SE202,SE202_courseStudents);

        User user = User.getInstance();
        StudentAffairsDirectorate studentAffairsDirectorate = StudentAffairsDirectorate.getInstance();
        AssignTag assignTagSE2 = new AssignTag(studentAffairsDirectorate,SE_2,SE2_CourseAndStudents);
        user.doCommand(assignTagSE2);


        //-------------------------------------------------------------------------------
        System.out.println("Please enter one of the following time to identify current courses in classrooms.");
        System.out.println("Pzt 10.00\n" + "Pzt 12.00");

        Scanner scanner = new Scanner(System.in);
        String time = scanner.nextLine();
        if (time.equalsIgnoreCase("Pzt 10.00")) {
            CE_1.setCurrentCourse(CE101);
            SE_1.setCurrentCourse(SE101);
            CE_2.setCurrentCourse(CE201);
            SE_2.setCurrentCourse(SE201);
            CE_3.setCurrentCourse(CE301);

        } else if (time.equalsIgnoreCase("Pzt 12.00")) {
            CE_1.setCurrentCourse(CE102);
            SE_1.setCurrentCourse(SE102);
            CE_2.setCurrentCourse(CE202);
            SE_2.setCurrentCourse(SE202);
        }
        else{
            System.out.println("Please enter a valid time zone");
        }
        //-------------------------------------------------------------------------------

        //Observer task 1b and task 6
        SecurityDepartment securityDepartment = new SecurityDepartment();
        securityDepartment.setIPLock(CE_1.getLock());
        securityDepartment.setIPLock(CE_2.getLock());
        securityDepartment.setIPLock(CE_3.getLock());
        securityDepartment.setIPLock(SE_1.getLock());
        securityDepartment.setIPLock(SE_2.getLock());
        CE_1.getLock().Attach(securityDepartment);
        CE_2.getLock().Attach(securityDepartment);
        CE_3.getLock().Attach(securityDepartment);
        SE_1.getLock().Attach(securityDepartment);
        SE_2.getLock().Attach(securityDepartment);

        //Create Floor Securities
        FloorSecurity CE_security = new FloorSecurity(CE_floor);
        FloorSecurity SE_security = new FloorSecurity(SE_floor);

        CE_security.openClassroom(CE_1);
        CE_security.openClassroom(CE_2);
        SE_security.openClassroom(SE_1);
        SE_security.openClassroom(SE_2);
        CE_security.openClassroom(CE_3);

        //Observer task4
        //Attach was done automatically.
        //Students touch nfc, students will be able to log in if they match the course in the class and the list of students in the course.
        ali.TouchNFC(CE_1);
        berkin.TouchNFC(CE_2);
        zeynep.TouchNFC(SE_1);
        tolunay.TouchNFC(SE_2);
        ufuk.TouchNFC(CE_3);

        System.out.println("------------------------");

        //Iterator task 5
        CampusSecurity campusSecurity = new CampusSecurity();
        campusSecurity.calculateSum(CE_floor);
        campusSecurity.calculateSum(SE_floor);
    }
}

