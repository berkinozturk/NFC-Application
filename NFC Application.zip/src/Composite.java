import java.util.ArrayList;
import java.util.HashMap;

interface Component {
    void Add(Component d);
    void Remove(Component d);
    void Display(int indent);
    public String getName();
    void Visit(AbstractAggregate aggregate);
}

//classrooms for floors, floors for faculties etc.
class CompositeElement implements Component {
    private String name;
    public String getName() { return name;}
    public CompositeElement(String name) {this.name = name;}
    public void Add(Component d) {elements.add(d);};
    public void Remove(Component d) {
        for (int i = 0; i< elements.size(); i++) {
            if (elements.get(i).getName() == d.getName()) {
                elements.remove(i);
                return;
            }
        }
    }

    public	void Display(int indent) {
        for(int i = 1;i <= indent;i++) System.out.print("-");
        System.out.println( "+ " + getName());

        for (int i= 0; i< elements.size(); i++) {
            elements.get(i).Display(indent+2);
        }
    }

    // get all components
    public void Visit(AbstractAggregate aggregate) {
        for (int i= 0; i< elements.size(); i++) {
            elements.get(i).Visit(aggregate);
        }
    }
    private ArrayList<Component> elements = new ArrayList<Component>();

    public ArrayList<Component> getElements() {
        return elements;
    }
}

class Classroom implements Component,StudentObserver {

    //--------------------------------Composite--------------------------------
    private String name;
    private Lock lock;
    private NFCTag NFCtag = new NFCTag("",new HashMap<>());

    public Classroom(String name) {
        this.name = name;
        CreateLock();
    }
    public NFCTag getNFCTag() {
        return NFCtag;
    }
    public void setNFCTag(NFCTag NFCTag) {
        this.NFCtag = NFCTag;
    }
    public Lock getLock() {
        return lock;
    }
    public void setLock(Lock lock) {
        this.lock = lock;
    }

    public String getName() { return name;}
    private void CreateLock(){
        lock = new Lock(name,true);
    }
    public void Add(Component c) {
        System.out.println("Cannot add to a Classroom.");
    }
    public  void Remove(Component c) {
        System.out.println("Cannot remove from a Classroom.");
    }
    public void Display(int indent) {
        for(int i = 1;i <= indent;i++) 	System.out.print("-");
        System.out.println(" "  + name);
    }

    // it adds students to the aggregate in classroom.
    public void Visit(AbstractAggregate aggregate) {
        getStudentsInClassroom().forEach((n) -> aggregate.add(n._name));
        if (getStudentsInClassroom().size() == 0){
            System.out.println("There are no students in "+ getName());
        }
    }

    //-------------------------Observer--------------------------------------
    private Students _students;
    private boolean _student_inClass;

    private Course currentCourse;

    private ArrayList<Students> studentsInClassroom = new ArrayList<>();
    public void Update(Students students) {
        _students = students;
        _student_inClass = students._inClass;
        System.out.println(_students._name+" entered " + name + ".");
    }

    public Students getStudent() {return _students;}

    public void set_student(Students _students) {
        this._students = _students;
    }

    public ArrayList<Students> getStudentsInClassroom() {
        return studentsInClassroom;
    }

    public Course getCurrentCourse() {
        return currentCourse;
    }

    public void setCurrentCourse(Course currentCourse) {
        this.currentCourse = currentCourse;
    }
}

// all floors have a different security personal.
// If the classroom match with the security, it can be opened.

class FloorSecurity {
    private CompositeElement element;

    public FloorSecurity(CompositeElement element) {
        this.element = element;
    }

    public void openClassroom (Classroom classroom){
        if (element.getElements().contains(classroom)){
            classroom.getLock().setisLock(false);
        }
    }

    public void lockClassroom(Classroom classroom){
        if (element.getElements().contains(classroom)){
            classroom.getLock().setisLock(true);
        }
    }
}

class CampusSecurity {
    void calculateSum(Component component) {

        AbstractAggregate aggregate = new Collection();
        component.Visit(aggregate);
        System.out.println(component.getName() + " have " + aggregate.getCount() + " students.");

    }
}

