import java.util.ArrayList;


// We are not using this class because it is not necessary class.

/* class IteratorPattern {
    static void printAggregate(AbstractIterator i) {
        System.out.println("Current Students:");
        for(i.First();  !i.IsDone(); i.Next()) {
            System.out.println(i.CurrentItem());
        }
        System.out.println();
    }
}
*/


//This is the abstract "Iterator".
//		AbstractIterator
interface  AbstractIterator {
    void First();
    void Next();
    Boolean IsDone () ;
    String CurrentItem() ;
}

//This is the "concrete" Iterator for collection.
//		CollectionIterator
class CollectionIterator implements AbstractIterator {
    public void First() {_current = 0;}
    public void Next()  {_current++; }
    public String CurrentItem() { return (IsDone()?null:_collection.get(_current)); }
    public Boolean IsDone() {	return _current >= _collection.getCount(); }
    public CollectionIterator(Collection collection) {
        _collection = collection;
        _current = 0;
    }
    private Collection _collection;
    private int _current;
};

interface AbstractAggregate {
    public AbstractIterator CreateIterator();
    public void add(String student); 		// Not needed for iteration.
    public int getCount (); // Needed for iteration.
    public String get(int idx); // Needed for iteration.
};

class Collection implements AbstractAggregate {
    private	 ArrayList<String> student = new ArrayList<String>();
    public	CollectionIterator CreateIterator() {
        return new CollectionIterator(this);
    }
    public int getCount () {return student.size(); }
    public void add(String student) {
        this.student.add(student);};
    public String get(int index) { return student.get(index);};
};
