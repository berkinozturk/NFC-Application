import java.util.ArrayList;

//'Observer'  ==> Abstract Observer
interface StudentObserver {
    public void Update(Students students);
}

//Subject
abstract class Students {
    public Students(String name) {
        _name = name;
    }
    //Register the Observers
    public void Attach (Classroom classroom) {
        if (!classrooms.contains(classroom)){
            classrooms.add(classroom);
        }
    }
    //Unregister from the list of Observers.
    public void Detach (Classroom classroom) {
        for (int i = 0; i< classrooms.size(); i++) {
            if (classrooms.get(i).getNFCTag() == classroom.getNFCTag()) {
                classrooms.remove(i);
                return;
            }
        }
    }

    //Notify the Observers.
    public void Notify() {
        for (int i = 0; i < classrooms.size(); i++) {
            classrooms.get(i).Update(this);
        }
    }

    public String get_name() {
        return _name;
    }

    public void set_name(String _name) {
        this._name = _name;
    }

    protected String _name;

    protected boolean _inClass = false;
    protected ArrayList<Classroom> classrooms = new ArrayList<Classroom>();
}

//ConcreteSubject
class Student extends Students {
    public Student(String name) {
        super(name);
    }

    private String getName() {return _name;}

    public void TouchNFC(Classroom classroom){

        if (classroom.getNFCTag().getCourseAndStudents().get(classroom.getCurrentCourse()) != null){

            if (classroom.getNFCTag().getCourseAndStudents().get(classroom.getCurrentCourse()).contains(this) && !classroom.getLock()._isLock && !classroom.getStudentsInClassroom().contains(this)){
                set_inClass(true);
                classroom.getStudentsInClassroom().add(this);
            }
        }
    }

    private void set_inClass(boolean value){
        _inClass = value;
        Notify();
    }
}

//'Classroom' class is in Composite.java, it is ConcreteSubject of ObserverTask4
