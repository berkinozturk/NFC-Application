import java.util.ArrayList;

//'Observer'  ==> Abstract Observer.
public interface Observer {
    public void Update(IP_Lock lock);
}

//Concrete Observer
class SecurityDepartment implements Observer {
    private IP_Lock _ipLock;
    private String _ipLock_name;
    private boolean _ipLock_isLock;
    @Override
    public void Update(IP_Lock lock) {
        _ipLock = lock;
        _ipLock_isLock = lock.getisLock();
        _ipLock_name = lock.getName();
        System.out.println(_ipLock_name + " door locked: " +_ipLock_isLock);
    }

    public IP_Lock getIPLock(){return _ipLock;}
    public void setIPLock(IP_Lock value) { _ipLock = value; }
}

//Subject
abstract class IP_Lock {
    public IP_Lock(String name,
                   boolean isLock) {
        _name = name;
        _isLock = isLock;
    }
    //Register the Observers
    public void Attach (SecurityDepartment security) {
        securityDepartment.add(security);
    }

    //Unregister from the list of Observers.
    public void Detach (SecurityDepartment security) {
        for (int i = 0; i< securityDepartment.size(); i++) {
            if (securityDepartment.get(i) == security) {
                securityDepartment.remove(i);
                return;
            }
        }
    }

    //Notify the Observers.
    public void Notify() {
        // set argument to something that helps
        // tell the Observers what happened
        for (int i = 0; i < securityDepartment.size(); i++) {
            securityDepartment.get(i).Update(this);
        }
    }
    public String getName() {return _name;}
    void setName(String value) {
        _name = value;}
    public boolean getisLock() {return false;};
    abstract public void setisLock(boolean value);
    protected String _name;          // Internal Subject state
    protected boolean _isLock;			// Internal Subject state
    protected ArrayList<SecurityDepartment> securityDepartment = new ArrayList<SecurityDepartment>();
}

//ConcreteSubject
class Lock extends IP_Lock{

    public Lock(String name, boolean isLock) {
        super(name, isLock);
    }
    public boolean getisLock() {return _isLock;}

    @Override
    public void setisLock(boolean value) {
        _isLock = value;
        Notify();
    }
}
